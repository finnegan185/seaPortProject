/*
 * CURRENTLY NOT USED
 */

package seaPortProject;

public class PortTime {
	//instance variables
	private int time;
	
	//constructor
	protected PortTime(int time) {
		super();
		this.time = time;
	}

	//getter
	public int getTime() {
		return time;
	}
	
	//setter
	public void setTime(int time) {
		this.time = time;
	}

}
